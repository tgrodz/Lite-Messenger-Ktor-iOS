import SwiftUI

@main
struct LiteMessengerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = MessengerViewModel()
    
    var body: some View {
        MessengerRootView(viewModel: viewModel)
    }
}

// MARK: - Root View

struct MessengerRootView: View {
    @ObservedObject var viewModel: MessengerViewModel
    
    var body: some View {
        Group {
            if viewModel.currentUser == nil {
                LoginView(viewModel: viewModel)
            } else {
                UserMessengerView(viewModel: viewModel)
            }
        }
        .animation(.easeInOut, value: viewModel.currentUser != nil)
    }
}

// MARK: - Login Screen

struct LoginView: View {
    @ObservedObject var viewModel: MessengerViewModel
    @FocusState private var focusedField: Field?
    
    private enum Field { case email, password }
    
    var body: some View {
        VStack {
            Spacer()
            VStack(spacing: 24) {
                VStack(spacing: 8) {
                    Text("Lite Messenger")
                        .font(.largeTitle.bold())
                    Text(viewModel.authMode == .login ? "Sign in to continue the conversation" : "Create an account to get started")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                if viewModel.authMode == .signup {
                    TextField("Full name", text: $viewModel.name)
                        .textInputAutocapitalization(.words)
                        .autocorrectionDisabled()
                        .padding()
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                }
                VStack(spacing: 16) {
                    TextField("Email", text: $viewModel.email)
                        .textInputAutocapitalization(.never)
                        .textContentType(.emailAddress)
                        .autocorrectionDisabled()
                        .padding()
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                        .focused($focusedField, equals: .email)
                    
                    SecureField("Password", text: $viewModel.password)
                        .padding()
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                        .focused($focusedField, equals: .password)
                }
                
                if let error = viewModel.loginError {
                    Text(error)
                        .font(.footnote)
                        .foregroundColor(.red)
                }
                
                Button(action: {
                    focusedField = nil
                    viewModel.submitAuth()
                }) {
                    HStack {
                        if viewModel.isAuthenticating {
                            ProgressView().tint(.white)
                        } else {
                            Image(systemName: viewModel.authMode == .login ? "arrow.right.circle.fill" : "person.crop.circle.badge.plus")
                            Text(viewModel.authMode == .login ? "Sign in" : "Create account")
                                .fontWeight(.semibold)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.indigo, in: RoundedRectangle(cornerRadius: 12))
                    .foregroundColor(.white)
                }
                .disabled(viewModel.isAuthenticating)
                
                Button(action: {
                    viewModel.toggleAuthMode()
                }) {
                    Text(viewModel.authMode == .login ? "Need an account? Sign up" : "Already have an account? Sign in")
                        .font(.footnote)
                        .foregroundColor(.indigo)
                }
            }
            .padding(32)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(Color(.systemBackground))
                    .shadow(color: Color.black.opacity(0.08), radius: 30)
            )
            .padding(.horizontal, 24)
            Spacer()
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
    }
}

// MARK: - Messenger Screen

struct UserMessengerView: View {
    @ObservedObject var viewModel: MessengerViewModel
    @Environment(\.horizontalSizeClass) private var sizeClass
    
    var body: some View {
        VStack(spacing: 0) {
            HeaderView(viewModel: viewModel)
            
            if sizeClass == .compact {
                compactLayout
            } else {
                desktopLayout
            }
        }
        .sheet(isPresented: $viewModel.showFilesSheet) {
            SettingsView(viewModel: viewModel)
        }
        .sheet(isPresented: $viewModel.showProfileSheet) {
            ProfileDetailView(viewModel: viewModel)
        }
    }
    
    private var desktopLayout: some View {
        HStack(spacing: 0) {
            SidebarView(viewModel: viewModel)
                .frame(width: 300)
                .background(Color(.systemGroupedBackground))
            
            Divider()
            MessageListView(viewModel: viewModel)
        }
    }
    
    private var compactLayout: some View {
        NavigationStack {
            SidebarView(viewModel: viewModel)
                .navigationDestination(item: $viewModel.selectedChat) { _ in
                    MessageListView(viewModel: viewModel)
                }
        }
    }
}

// MARK: - Header

struct HeaderView: View {
    @ObservedObject var viewModel: MessengerViewModel
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Messenger")
                    .font(.title2.bold())
                Text("Connected as \(viewModel.currentUser?.name ?? "")")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            if let user = viewModel.currentUser {
                Button {
                    viewModel.showProfileSheet = true
                } label: {
                    HStack(spacing: 12) {
                        AvatarView(name: user.name, color: user.color)
                        VStack(alignment: .trailing, spacing: 2) {
                            Text(user.name)
                                .fontWeight(.semibold)
                            Text(user.status)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
            
            Button {
                viewModel.showFilesSheet = true
            } label: {
                Label("Files", systemImage: "folder.fill")
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color(.secondarySystemBackground), in: Capsule())
            }
            .buttonStyle(.plain)
        }
        .padding()
        .background(Color(.systemBackground))
    }
}

// MARK: - Sidebar

struct SidebarView: View {
    @ObservedObject var viewModel: MessengerViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            SearchBar(text: $viewModel.searchQuery, placeholder: "Find a new user and add to chat")
                .onChange(of: viewModel.searchQuery) { old, new in
                    viewModel.searchUsers()
                }
            
            if !viewModel.searchResults.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Suggestions")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    ForEach(viewModel.searchResults) { user in
                        Button {
                            viewModel.startChat(with: user)
                        } label: {
                            HStack {
                                AvatarView(name: user.name, color: user.color)
                                VStack(alignment: .leading) {
                                    Text(user.name)
                                        .fontWeight(.semibold)
                                    Text(user.role)
                                        .foregroundColor(.secondary)
                                        .font(.caption)
                                }
                                Spacer()
                            }
                            .padding(8)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            
            Text("Chats")
                .font(.headline)
                .padding(.top, 8)
            
            ScrollView {
                VStack(spacing: 8) {
                    ForEach(viewModel.chats) { chat in
                        ChatRow(chat: chat,
                                isSelected: chat.id == viewModel.selectedChat?.id,
                                currentUser: viewModel.currentUser,
                                lastMessageText: chat.messages.last?.text ?? "") {
                            viewModel.select(chat: chat)
                        }
                    }
                }
            }
        }
        .padding()
    }
}

// MARK: - Messages

struct MessageListView: View {
    @ObservedObject var viewModel: MessengerViewModel
    @State private var draft = ""
    
    var body: some View {
        VStack(spacing: 0) {
            if let chat = viewModel.selectedChat, let current = viewModel.currentUser {
                ScrollViewReader { proxy in
                    List {
                        ForEach(chat.messages) { message in
                            MessageBubble(message: message, isCurrentUser: message.sender == current)
                                .listRowSeparator(.hidden)
                                .id(message.id)
                        }
                    }
                    .listStyle(.plain)
                    .onChange(of: chat.messages.count) { _, _ in
                        if let lastID = chat.messages.last?.id {
                            DispatchQueue.main.async {
                                withAnimation { proxy.scrollTo(lastID, anchor: .bottom) }
                            }
                        }
                    }
                }
                
                Divider()
                
                HStack {
                    TextField("Message", text: $draft, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                    
                    Button {
                        viewModel.send(message: draft)
                        draft.removeAll()
                    } label: {
                        Image(systemName: "paperplane.fill")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.indigo, in: Circle())
                    }
                    .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                .padding()
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "bubble.left.and.bubble.right.fill")
                        .font(.system(size: 42))
                        .foregroundColor(.secondary)
                    Text("Select a chat to get started")
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }
}

// MARK: - Chat Row & Message Bubble

struct ChatRow: View {
    let chat: ChatThread
    let isSelected: Bool
    let currentUser: MessengerUser?
    let lastMessageText: String
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                AvatarView(name: chat.contactName(excluding: currentUser), color: chat.contactColor(excluding: currentUser))
                VStack(alignment: .leading, spacing: 4) {
                    Text(chat.contactName(excluding: currentUser))
                        .fontWeight(.semibold)
                    Text(lastMessageText)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                Text(chat.messages.last.map { MessengerFormatter.relativeDateString(from: $0.timestamp) } ?? "")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            .padding(10)
            .background(isSelected ? Color.indigo.opacity(0.1) : Color.clear, in: RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }
}

struct MessageBubble: View {
    let message: MessageModel
    let isCurrentUser: Bool
    
    var body: some View {
        HStack {
            if isCurrentUser { Spacer() }
            VStack(alignment: isCurrentUser ? .trailing : .leading, spacing: 4) {
                Text(message.sender.name)
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(message.text)
                    .padding()
                    .background(isCurrentUser ? Color.indigo : Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
                    .foregroundColor(isCurrentUser ? .white : .primary)
                Text(MessengerFormatter.timeString(from: message.timestamp))
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            if !isCurrentUser { Spacer() }
        }
        .transition(.move(edge: isCurrentUser ? .trailing : .leading))
        .padding(.vertical, 4)
    }
}

// MARK: - Profile & Settings

struct ProfileDetailView: View {
    @ObservedObject var viewModel: MessengerViewModel
    
    var body: some View {
        if let user = viewModel.currentUser {
            NavigationStack {
                Form {
                    Section("Profile") {
                        HStack {
                            AvatarView(name: user.name, color: user.color)
                            VStack(alignment: .leading) {
                                Text(user.name).font(.headline)
                                Text(user.email).font(.subheadline).foregroundColor(.secondary)
                            }
                        }
                        Label(user.role, systemImage: "briefcase.fill")
                        Label(user.status, systemImage: "waveform.path.ecg.rectangle")
                    }
                }
                .navigationTitle("Your Profile")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Close") { viewModel.showProfileSheet = false }
                    }
                }
            }
        }
    }
}

struct SettingsView: View {
    @ObservedObject var viewModel: MessengerViewModel
    @State private var draftUser: MessengerUser
    
    init(viewModel: MessengerViewModel) {
        self._viewModel = ObservedObject(wrappedValue: viewModel)
        _draftUser = State(initialValue: viewModel.currentUser ?? .placeholder)
    }
    @State private var pushEnabled = true
    @State private var readReceipts = true
    
    var body: some View {
        NavigationStack {
            Form {
                Section("Account") {
                    TextField("Name", text: Binding(get: { draftUser.name }, set: { draftUser.name = $0 }))
                    TextField("Role", text: Binding(get: { draftUser.role }, set: { draftUser.role = $0 }))
                    TextField("Status", text: Binding(get: { draftUser.status }, set: { draftUser.status = $0 }))
                }
                
                Section("Preferences") {
                    Toggle("Push notifications", isOn: $pushEnabled)
                    Toggle("Read receipts", isOn: $readReceipts)
                    TextField("Bio", text: Binding(get: { draftUser.bio }, set: { draftUser.bio = $0 }), axis: .vertical)
                        .lineLimit(3, reservesSpace: true)
                }
            }
            .navigationTitle("Files & Settings")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { viewModel.showFilesSheet = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        viewModel.updateUser(with: draftUser)
                        viewModel.showFilesSheet = false
                    }
                }
            }
            .onAppear {
                draftUser = viewModel.currentUser ?? .placeholder
            }
        }
    }
}

// MARK: - Components

struct AvatarView: View {
    let name: String
    let color: Color
    
    var body: some View {
        Text(AvatarGenerator.initials(for: name))
            .fontWeight(.bold)
            .frame(width: 44, height: 44)
            .background(color.gradient, in: Circle())
            .foregroundColor(.white)
    }
}

struct SearchBar: View {
    @Binding var text: String
    let placeholder: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
            TextField(placeholder, text: $text)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            if !text.isEmpty {
                Button {
                    text.removeAll()
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(10)
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - ViewModel

final class MessengerViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var name = ""
    @Published var loginError: String?
    @Published var isAuthenticating = false
    @Published var authMode: AuthMode = .login
    
    @Published private(set) var currentUser: MessengerUser?
    @Published private(set) var chats: [ChatThread] = []
    @Published var selectedChat: ChatThread?
    
    @Published var searchQuery = ""
    @Published var searchResults: [MessengerUser] = []
    @Published var showFilesSheet = false
    @Published var showProfileSheet = false
    
    private let repository = MessengerRepository()
    
    enum AuthMode {
        case login
        case signup
    }
    
    func submitAuth() {
        loginError = nil
        switch authMode {
        case .login:
            guard !email.isEmpty, !password.isEmpty else {
                loginError = "Enter both email and password."
                return
            }
        case .signup:
            guard !name.trimmingCharacters(in: .whitespaces).isEmpty else {
                loginError = "Name is required."
                return
            }
            guard !email.isEmpty, !password.isEmpty else {
                loginError = "Email and password are required."
                return
            }
        }
        
        isAuthenticating = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            defer { self.isAuthenticating = false }
            switch self.authMode {
            case .login:
                guard let user = self.repository.authenticate(email: self.email, password: self.password) else {
                    self.loginError = "Invalid credentials"
                    return
                }
                self.completeAuth(for: user)
            case .signup:
                guard let user = self.repository.createAccount(name: self.name, email: self.email, password: self.password) else {
                    self.loginError = "Account already exists."
                    return
                }
                self.completeAuth(for: user)
            }
        }
    }
    
    func toggleAuthMode() {
        authMode = authMode == .login ? .signup : .login
        loginError = nil
    }
    
    private func completeAuth(for user: MessengerUser) {
        currentUser = user
        chats = repository.loadChats(for: user)
        selectedChat = chats.first
        email.removeAll()
        password.removeAll()
        if authMode == .signup {
            name.removeAll()
        }
    }
    
    func logout() {
        currentUser = nil
        chats.removeAll()
        selectedChat = nil
    }
    
    func select(chat: ChatThread) {
        selectedChat = chat
    }
    
    func send(message: String) {
        guard let currentUser, let selectedChat else { return }
        let trimmed = message.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        chats = repository.send(message: trimmed, from: currentUser, in: selectedChat.id)
        self.selectedChat = chats.first(where: { $0.id == selectedChat.id })
    }
    
    func searchUsers() {
        guard let currentUser else {
            searchResults = []
            return
        }
        searchResults = repository.searchUsers(query: searchQuery, excluding: currentUser)
    }
    
    func startChat(with other: MessengerUser) {
        guard let currentUser else { return }
        selectedChat = repository.startChat(between: currentUser, and: other)
        chats = repository.loadChats(for: currentUser)
        searchQuery.removeAll()
        searchResults.removeAll()
    }
    
    func updateUser(with updated: MessengerUser) {
        guard currentUser != nil else { return }
        repository.updateProfile(updated)
        currentUser = updated
        chats = repository.loadChats(for: updated)
        if let selectedChat {
            self.selectedChat = chats.first(where: { $0.id == selectedChat.id })
        }
    }
}

// MARK: - Repository & Domain

struct MessengerUser: Identifiable, Equatable {
    let id: UUID
    var name: String
    var email: String
    var role: String
    var status: String
    var bio: String
    var color: Color
    
    static let placeholder = MessengerUser(
        id: UUID(),
        name: "New User",
        email: "placeholder@example.com",
        role: "Contributor",
        status: "Available",
        bio: "Tell others about yourself.",
        color: .gray
    )
}

struct MessageModel: Identifiable, Equatable {
    let id: UUID
    let sender: MessengerUser
    let text: String
    let timestamp: Date
    
    init(id: UUID = UUID(), sender: MessengerUser, text: String, timestamp: Date) {
        self.id = id
        self.sender = sender
        self.text = text
        self.timestamp = timestamp
    }
}

struct ChatThread: Identifiable, Equatable, Hashable {
    let id: UUID
    var participants: [MessengerUser]
    var messages: [MessageModel]
    
    static func == (lhs: ChatThread, rhs: ChatThread) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    func contactName(excluding current: MessengerUser?) -> String {
        if let current, let other = participants.first(where: { $0.id != current.id }) {
            return other.name
        }
        return participants.first?.name ?? "Unknown"
    }
    
    func contactColor(excluding current: MessengerUser?) -> Color {
        if let current, let other = participants.first(where: { $0.id != current.id }) {
            return other.color
        }
        return participants.first?.color ?? .gray
    }
}

final class MessengerRepository {
    private var credentials: [String: (MessengerUser, String)] = [:]
    private var chats: [UUID: ChatThread] = [:]
    
    init() {
        let jordan = MessengerUser(id: UUID(), name: "User One", email: "user1@email.com", role: "Product Designer", status: "Available", bio: "Design-driven communicator.", color: .indigo)
        let maria = MessengerUser(id: UUID(), name: "Maria Alvarez", email: "maria@studio.com", role: "iOS Engineer", status: "Working remotely", bio: "Building flows and shipping them fast.", color: .pink)
        let andrew = MessengerUser(id: UUID(), name: "Andrew Kim", email: "andrew@studio.com", role: "QA Lead", status: "Reviewing builds", bio: "Testing saves future headaches.", color: .orange)
        let laila = MessengerUser(id: UUID(), name: "Laila Rahman", email: "laila@studio.com", role: "Marketing", status: "In meetings", bio: "Stories that connect.", color: .green)
        
        credentials[jordan.email.lowercased()] = (jordan, "123456")
        credentials[maria.email.lowercased()] = (maria, "password")
        credentials[andrew.email.lowercased()] = (andrew, "password")
        credentials[laila.email.lowercased()] = (laila, "password")
        
        let chat1 = ChatThread(
            id: UUID(),
            participants: [jordan, maria],
            messages: [
                MessageModel(sender: maria, text: "Morning! Did you see the new design review?", timestamp: Date().addingTimeInterval(-3600)),
                MessageModel(sender: jordan, text: "Yep, I left some notes for the animation states.", timestamp: Date().addingTimeInterval(-3500)),
                MessageModel(sender: maria, text: "Perfect, I’ll push another build after lunch.", timestamp: Date().addingTimeInterval(-3200))
            ]
        )
        let chat2 = ChatThread(
            id: UUID(),
            participants: [jordan, andrew],
            messages: [
                MessageModel(sender: andrew, text: "I caught two regressions in the compose screen.", timestamp: Date().addingTimeInterval(-7200)),
                MessageModel(sender: jordan, text: "Thanks! I can patch them today.", timestamp: Date().addingTimeInterval(-7150))
            ]
        )
        let chat3 = ChatThread(
            id: UUID(),
            participants: [jordan, laila],
            messages: [
                MessageModel(sender: laila, text: "Campaign copy is ready for review.", timestamp: Date().addingTimeInterval(-10800)),
                MessageModel(sender: jordan, text: "Awesome, I’ll plug it into the prototype tonight.", timestamp: Date().addingTimeInterval(-9800))
            ]
        )
        chats[chat1.id] = chat1
        chats[chat2.id] = chat2
        chats[chat3.id] = chat3
    }
    
    func authenticate(email: String, password: String) -> MessengerUser? {
        guard let entry = credentials[email.lowercased()], entry.1 == password else { return nil }
        return entry.0
    }
    
    func createAccount(name: String, email: String, password: String) -> MessengerUser? {
        guard credentials[email.lowercased()] == nil else { return nil }
        let newUser = MessengerUser(
            id: UUID(),
            name: name,
            email: email,
            role: "New Member",
            status: "Online",
            bio: "Loving conversations.",
            color: .blue
        )
        credentials[email.lowercased()] = (newUser, password)
        return newUser
    }
    
    func loadChats(for user: MessengerUser) -> [ChatThread] {
        chats.values
            .filter { chat in chat.participants.contains { $0.id == user.id } }
            .sorted { ($0.messages.last?.timestamp ?? .distantPast) > ($1.messages.last?.timestamp ?? .distantPast) }
    }
    
    func send(message: String, from sender: MessengerUser, in chatID: UUID) -> [ChatThread] {
        guard var chat = chats[chatID] else { return Array(chats.values) }
        let newMessage = MessageModel(sender: sender, text: message, timestamp: Date())
        chat.messages.append(newMessage)
        chats[chatID] = chat
        return loadChats(for: sender)
    }
    
    func searchUsers(query: String, excluding current: MessengerUser) -> [MessengerUser] {
        guard !query.isEmpty else { return [] }
        let lower = query.lowercased()
        return Array(credentials.values
            .map { $0.0 }
            .filter { $0 != current }
            .filter { $0.name.lowercased().contains(lower) || $0.email.lowercased().contains(lower) }
            .prefix(5))
    }
    
    func startChat(between current: MessengerUser, and other: MessengerUser) -> ChatThread {
        if let existing = chats.values.first(where: { chat in
            chat.participants.contains(where: { $0.id == current.id }) &&
            chat.participants.contains(where: { $0.id == other.id })
        }) {
            return existing
        }
        let newChat = ChatThread(id: UUID(), participants: [current, other], messages: [])
        chats[newChat.id] = newChat
        return newChat
    }
    
    func updateProfile(_ updated: MessengerUser) {
        if let entry = credentials.first(where: { $0.value.0.id == updated.id }) {
            credentials.removeValue(forKey: entry.key)
            credentials[updated.email.lowercased()] = (updated, entry.value.1)
        } else {
            credentials[updated.email.lowercased()] = (updated, "123456")
        }
        for key in chats.keys {
            var chat = chats[key]!
            chat.participants = chat.participants.map { $0.id == updated.id ? updated : $0 }
            chat.messages = chat.messages.map { message in
                if message.sender.id == updated.id {
                    return MessageModel(id: message.id, sender: updated, text: message.text, timestamp: message.timestamp)
                }
                return message
            }
            chats[key] = chat
        }
    }
}

// MARK: - Utilities

enum AvatarGenerator {
    static func initials(for name: String) -> String {
        let components = name.split(separator: " ").map(String.init)
        let initials = components.prefix(2).compactMap { $0.first }.map { String($0) }.joined()
        return initials.isEmpty ? "?" : initials.uppercased()
    }
}

enum MessengerFormatter {
    static func timeString(from date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    static func relativeDateString(from date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}
